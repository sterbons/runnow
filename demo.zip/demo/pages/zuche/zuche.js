const app = getApp();
Page({
  onShareAppMessage: function () {
      return {
          title: '校园租车',
          desc: '校园租车'
      }
  },
  data: {
    userInfo: {},
    imgbx:{
      topImg:'/images/p1-top.png',
      titImg:'/images/p1-tit.png',
      bomImg:'/images/p1-bom.png'
    },
    button: {
      defaultSize: 'default',
      disabled: false,
      plain: false,
      loading: false
    },
    houseType: ['2-5块', '5-10块','10-15块','15-20块','20-30块','30-50块','其他金额'],
    houseTypeIndex: 0,
    inputContent: {}
  },
  onLoad () {
    let that = this
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function(userInfo){
      //更新数据
      that.setData({
        userInfo:userInfo
      });
    })
  }, 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showToast({
      title: '刷新成功',
      icon:'sucess',
      duration:1000
    })
    wx.stopPullDownRefresh({
      success: (res) => {},
    })

  },
  bindPickerChange (e) {
    let _this  = this;
    _this.setData({
      houseTypeIndex: e.detail.value
    })
  },
  findHouse (e){
    let _this  = this;
    let _datas = 0;
    let _types = _this.data.houseTypeIndex;
    let _salary = _this.data.inputContent.currentSalary;

    // wx.navigateTo({
    //   url: '../logs/logs?type=1'
    // });
    // return false;

    if(typeof(_salary) == 'undefined' || !_salary){
       wx.showModal({
          title: '提示',
          content: '请输入车辆类型',
          showCancel:false
       });
       return false;
    }

    if(_types == 0 && _salary < 10000){
        _datas= 0;
    }
    else if(_types == 1 && _salary < 10000){
        _datas= 1;
    }
    else if(_types == 0 && _salary > 10000){
         _datas= 2;
    }
    else if (_types == 1 && _salary > 10000){
         _datas= 3;
    }

    wx.navigateTo({
      url: '../content/content?type='+_datas
    });
  },
  bindchangeInput (e) {
    this.data.inputContent[e.currentTarget.id] = e.detail.value;
  }

})
