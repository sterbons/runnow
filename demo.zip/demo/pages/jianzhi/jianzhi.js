Page(
  {
    data:{
      tabs:[
        {
          id: 0,
          value: "综合",
          isActive: true
          },
          {
            id: 1,
            value: "距离",
            isActive: false
            },
            {
              id: 2,
              value: "待遇",
              isActive: false
              }
      ],

    },
    /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showToast({
      title: '刷新成功',
      icon:'sucess',
      duration:900,
      success: (res) => {
        this.setData.title='刷新了',
        this.setData.icon='success'
      
      },
      
    })
    wx.stopPullDownRefresh({
      success: (res) => {
      },
    })
  },

    handleTabsItemChange(e){
      const {index}=e.detail;
      let {tabs}=this.data;
      tabs.forEach((v,i)=>i==index?v.isActive=true:v.isActive=false);

      this.setData({
        tabs
      })
    },
  }
)